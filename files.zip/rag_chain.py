"""
Phase 2: RAG Chain — LLM Integration with Hugging Face Inference API
=====================================================================
This script connects your working ChromaDB (Phase 1) to a free LLM.
It retrieves relevant chunks and generates grounded, accurate answers.

Usage:
    python src/rag_chain.py

Prerequisites:
    - Phase 1 complete (chroma_db/ folder exists with embedded chunks)
    - HUGGINGFACE_API_KEY set in your .env file
    - venv activated
"""

import os
import sys
from dotenv import load_dotenv

# ─────────────────────────────────────────────
# Step 1: Load environment variables FIRST
# ─────────────────────────────────────────────
load_dotenv()  # Reads your .env file

HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")

if not HUGGINGFACE_API_KEY:
    print("\n❌ ERROR: HUGGINGFACE_API_KEY not found in .env file.")
    print("   Fix: Open your .env file and add your key:")
    print("   HUGGINGFACE_API_KEY=hf_xxxxxxxxxxxxxxxxxxxxxxxxxx")
    print("\n   Get your free key at: https://huggingface.co/settings/tokens")
    print("   Token type: 'Read' access is enough.\n")
    sys.exit(1)

print("✅ API key loaded from .env")

# ─────────────────────────────────────────────
# Step 2: Import libraries AFTER env check
# ─────────────────────────────────────────────
# (No point importing heavy libraries if the key is missing)

from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.messages import HumanMessage, AIMessage
from langchain_community.llms import HuggingFaceEndpoint

# ─────────────────────────────────────────────
# Step 3: Connect to your existing ChromaDB
# ─────────────────────────────────────────────
# This reuses the EXACT same database you built in Phase 1.
# It does NOT re-embed anything — just opens the filing cabinet.

CHROMA_PATH = "./chroma_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

print("⏳ Loading vector database...")

try:
    embedding_function = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    vectorstore = Chroma(
        persist_directory=CHROMA_PATH,
        embedding_function=embedding_function
    )
    # Quick sanity check — make sure there are actually chunks in there
    collection = vectorstore._collection
    doc_count = collection.count()
    if doc_count == 0:
        print("\n❌ ERROR: ChromaDB is empty. Did you run Phase 1?")
        print("   Fix: Run your vectorstore.py script first to embed your PDF.\n")
        sys.exit(1)
    print(f"✅ ChromaDB loaded — {doc_count} chunks available")
except Exception as e:
    print(f"\n❌ ERROR: Could not load ChromaDB from '{CHROMA_PATH}'")
    print(f"   Details: {e}")
    print("   Fix: Make sure you ran Phase 1 and the chroma_db/ folder exists.\n")
    sys.exit(1)

# ─────────────────────────────────────────────
# Step 4: Set up the retriever
# ─────────────────────────────────────────────
# top_k=4 means: for each question, grab the 4 most relevant paragraphs.
# This is the "super-librarian" pulling files from the cabinet.

retriever = vectorstore.as_retriever(
    search_type="similarity",
    search_kwargs={"k": 4}
)

print("✅ Retriever ready (top 4 chunks per query)")

# ─────────────────────────────────────────────
# Step 5: Initialize the Hugging Face LLM
# ─────────────────────────────────────────────
# Using the FREE Inference API — no GPU needed, no downloads.
# Mistral-7B-Instruct is a solid free model for Q&A tasks.

# ── TRAP AVOIDED: Model choice ──
# Don't use base models (like "mistralai/Mistral-7B-v0.3") — they
# don't follow instructions. Always use "-Instruct" variants.

MODEL_ID = "mistralai/Mistral-7B-Instruct-v0.3"

print(f"⏳ Connecting to Hugging Face model: {MODEL_ID}")

try:
    llm = HuggingFaceEndpoint(
        repo_id=MODEL_ID,
        huggingfacehub_api_token=HUGGINGFACE_API_KEY,
        max_new_tokens=512,       # Max length of generated answer
        temperature=0.1,          # Low = more factual, less creative
        top_p=0.9,                # Nucleus sampling — keeps answers focused
        repetition_penalty=1.1,   # Prevents the model from repeating itself
    )
    print("✅ LLM connected")
except Exception as e:
    print(f"\n❌ ERROR: Could not connect to Hugging Face API.")
    print(f"   Details: {e}")
    print("   Common fixes:")
    print("   1. Check your API key is correct in .env")
    print("   2. Check your internet connection")
    print("   3. The model may be loading (free tier has cold starts — wait 60s and retry)\n")
    sys.exit(1)

# ─────────────────────────────────────────────
# Step 6: The Anti-Hallucination System Prompt
# ─────────────────────────────────────────────
# This is your GUARDRAIL. Without this, the LLM will make up laws.
# The prompt forces the LLM to ONLY use retrieved context.

SYSTEM_PROMPT = """You are a UK legal and regulatory assistant. Your job is to answer questions accurately using ONLY the provided context from official UK documents.

STRICT RULES:
1. ONLY use information from the CONTEXT below to answer.
2. If the answer is NOT in the context, reply exactly: "I cannot find this information in the provided documents. Please check the official UK government website at gov.uk for the most current guidance."
3. Do NOT make up laws, regulations, dates, or numbers.
4. Quote the relevant section when possible.
5. Keep answers concise and professional.
6. If the context is partially relevant, say what you CAN confirm and what you CANNOT.

CONTEXT:
{context}

CHAT HISTORY:
{chat_history}
"""

# ─────────────────────────────────────────────
# Step 7: Build the RAG chain
# ─────────────────────────────────────────────
# This wires everything together:
# Question → Retriever → Prompt + Context → LLM → Answer

prompt = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    ("human", "{question}")
])

def format_docs(docs):
    """Turn retrieved Document objects into a single text block."""
    formatted = []
    for i, doc in enumerate(docs, 1):
        source = doc.metadata.get("source", "Unknown")
        page = doc.metadata.get("page", "?")
        formatted.append(
            f"[Source {i}: {source}, Page {page}]\n{doc.page_content}"
        )
    return "\n\n---\n\n".join(formatted)

# ─────────────────────────────────────────────
# Step 8: Conversational Memory
# ─────────────────────────────────────────────
# Without this, the bot forgets every question instantly.
# We store chat history as a simple list of messages.

# ── TRAP AVOIDED: Streamlit reruns ──
# We use a plain list here (not LangChain's Memory classes) because
# it's simpler, easier to debug, and works the same way when we
# later connect to FastAPI and Streamlit.

chat_history = []  # Stores tuples of (user_question, ai_answer)

def format_chat_history(history):
    """Convert chat history list into a readable string for the prompt."""
    if not history:
        return "No previous conversation."
    lines = []
    for human_msg, ai_msg in history[-5:]:  # Only keep last 5 exchanges
        lines.append(f"User: {human_msg}")
        lines.append(f"Assistant: {ai_msg}")
    return "\n".join(lines)

# ─────────────────────────────────────────────
# Step 9: The main ask() function
# ─────────────────────────────────────────────
# This is the single function you'll reuse in Phase 3 (FastAPI)
# and Phase 4 (Streamlit). Build it right once, use it everywhere.

def ask(question: str) -> dict:
    """
    Ask a question about your UK regulatory documents.
    
    Args:
        question: The user's question as a string.
        
    Returns:
        dict with keys:
            - "answer": The LLM's response
            - "sources": List of source documents used
            - "num_chunks": How many chunks were retrieved
    """
    try:
        # Step A: Retrieve relevant chunks
        retrieved_docs = retriever.invoke(question)
        
        if not retrieved_docs:
            return {
                "answer": "No relevant documents found in the database.",
                "sources": [],
                "num_chunks": 0
            }
        
        # Step B: Format context and history
        context_text = format_docs(retrieved_docs)
        history_text = format_chat_history(chat_history)
        
        # Step C: Build the final prompt and call the LLM
        chain = prompt | llm | StrOutputParser()
        
        answer = chain.invoke({
            "context": context_text,
            "chat_history": history_text,
            "question": question
        })
        
        # Step D: Clean up the answer
        # HF models sometimes echo the prompt or add artifacts
        answer = answer.strip()
        
        # Step E: Update conversation memory
        chat_history.append((question, answer))
        
        # Step F: Prepare source info (for transparency)
        sources = []
        for doc in retrieved_docs:
            sources.append({
                "source": doc.metadata.get("source", "Unknown"),
                "page": doc.metadata.get("page", "?"),
                "preview": doc.page_content[:100] + "..."
            })
        
        return {
            "answer": answer,
            "sources": sources,
            "num_chunks": len(retrieved_docs)
        }
        
    except Exception as e:
        error_msg = str(e)
        
        # ── TRAP AVOIDED: Common HF errors with helpful messages ──
        if "429" in error_msg or "rate" in error_msg.lower():
            return {
                "answer": "⚠️ Rate limit hit. The free Hugging Face tier limits requests. Wait 60 seconds and try again.",
                "sources": [],
                "num_chunks": 0
            }
        elif "503" in error_msg or "loading" in error_msg.lower():
            return {
                "answer": "⏳ The model is loading on Hugging Face servers (cold start). This takes 30-60 seconds on the free tier. Please try again shortly.",
                "sources": [],
                "num_chunks": 0
            }
        elif "401" in error_msg or "unauthorized" in error_msg.lower():
            return {
                "answer": "❌ API key is invalid. Check your HUGGINGFACE_API_KEY in the .env file.",
                "sources": [],
                "num_chunks": 0
            }
        else:
            return {
                "answer": f"❌ Unexpected error: {error_msg}",
                "sources": [],
                "num_chunks": 0
            }


# ─────────────────────────────────────────────
# Step 10: Interactive Terminal Chat Loop
# ─────────────────────────────────────────────
# This lets you test the entire pipeline from your terminal.
# Type questions, get answers, verify it works before Phase 3.

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  UK Legal Document Assistant — Phase 2 Test")
    print("  Type your questions below. Type 'quit' to exit.")
    print("  Type 'sources' to see what chunks were used.")
    print("  Type 'clear' to reset conversation memory.")
    print("=" * 60 + "\n")
    
    last_result = None
    
    while True:
        try:
            user_input = input("📝 You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye! 👋")
            break
        
        if not user_input:
            continue
        
        if user_input.lower() == "quit":
            print("\nGoodbye! 👋")
            break
        
        if user_input.lower() == "clear":
            chat_history.clear()
            print("🗑️  Conversation memory cleared.\n")
            continue
        
        if user_input.lower() == "sources":
            if last_result and last_result["sources"]:
                print("\n📚 Sources used in last answer:")
                for i, src in enumerate(last_result["sources"], 1):
                    print(f"   [{i}] {src['source']} (Page {src['page']})")
                    print(f"       Preview: {src['preview']}")
                print()
            else:
                print("   No sources available. Ask a question first.\n")
            continue
        
        print("⏳ Thinking...")
        result = ask(user_input)
        last_result = result
        
        print(f"\n🤖 Assistant: {result['answer']}")
        print(f"   (Used {result['num_chunks']} chunks from your documents)\n")
